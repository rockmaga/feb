from django.contrib.contenttypes.views import shortcut
from django.urls import path, include
from .views import collect, star
from .col   import index


app_name = 'cs'

urlpatterns = [
    path('', index, name='index'),
    path('column/<int:cpk>', index, name='column'),
    path('u<int:upk>/collections', collect, name='collections'),
    path('u<int:upk>/collections/<int:cpk>', collect, name='collections'),
    path('u<int:upk>/collection/<cType>/<int:cpk>/', collect, name='collection'),
    path('u<int:upk>/collect/<cType>/<int:cpk>/<action>', collect, name='collect'),
    
    path('u<int:upk>/star/<cType>/<int:spk>/<action>', star, name='star')
]
