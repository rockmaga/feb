from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.decorators     import login_required
from django.shortcuts import render, get_object_or_404
from django.db.models import F
from Userx.models import Party, Friend, User
from press.models import Press
from Userx.utils  import UX, CTX
from .views     import  Collect, STAR
from .models    import Collection, Star, Score

class AD:
    def __init__(self, pk, title, subtitle, content, create_time):
        self.pk = pk
        self.title = title
        self.subtitle = subtitle
        self.content = content
        self.create_time = create_time
    def __str__(self):
        return '{}'.format(self.title)

default_ad = AD(0, '神奇的网站', '我要变成世界第一土壕了', '打败腾讯，打败百度，打败那怕些狗屁网站', '2019')

mega_ad = [
    AD(0, '创业之路', '吕超', '不想成为架构师的艺术家不是好将军！', 2020),
    AD(0, '移民到美国','理查德',  '傲为美国公民！', 2022),
    AD(0,  '颍上', 'Richad lv', '中国新型城市不一样的崛起之路', 2023),
]

class COL:
    def __init__(self, request, *args, **kwargs):
        self.request = request
        self.upk = kwargs.pop('upk', None)
        self.cpk = kwargs.pop('cpk', None)
        self.user = UX(self.request, upk=self.upk)

    def col(self):
        col = Party.objects.get(pk=self.cpk) if self.cpk else None
        return col.party if col else None

    def headline(self):
        # 获取当前用户所有好友的文章分数排名 
        # TODO :限定不同日期
        wps = [ wp.pk for wp in Press.objects.filter(author__in=self.user.friends()) ]#if self.user.friends() else []
        HD = [wp.content_object for wp in  Score.objects.filter(object_pk__in=wps).order_by(F('score').desc()) ] # if wps else []
        return HD
 
    def wps_under_col(self):
        # 根据不同Col 即party，把当前用户party中的用户的文章归类
        # TODO :限定不同日期

        from collections import defaultdict
        col = defaultdict(list)
        for p, f in self.user.members().items():
            # 取得当前属于当前party 下的好友的文章， 并且不属于首页的文章列表
            # 注：已经出现在首页就不让它再出现一次了， 目前首页显示三篇文章，因此是[0；2]
            col[p.pk].extend([w for w in Press.objects.filter(author__in=f) if w not in self.headline()[0:2]])
        return col


@login_required
def index(request, *args, **kwargs):
    column = COL(request, upk=None, *args, **kwargs)
    template_name = 'cs/column.html' if column.cpk else 'cs/index.html'

    TT = column.headline()
    cols_wps = column.wps_under_col()

    context = {
        'index': '| {}'.format(column.col()) if column.col() else '',
        'headline': TT[0] if len(TT) else default_ad,
        'neckline_1': TT[1] if len(TT)>1 else default_ad,
        'neckline_2': TT[2] if len(TT)>2 else default_ad,
        'cols': column.user.parties(),
        'user': column.user.account(),
        'wps':cols_wps[column.cpk] if column.cpk else [],
        'ads': mega_ad[0],
    }

    friends_request = Friend.objects.unrejected_requests(user=request.user) if request.user.id else None
    if friends_request:
        f_req_list = [ get_object_or_404(FriendshipRequest, id=h.id) for h in friends_request ]
        ctx['f_req_list'] = f_req_list

    context.update(CTX)
    return render(request, template_name, context)