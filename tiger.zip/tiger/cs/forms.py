import time
from django import forms
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.forms.utils import ErrorDict
from django.utils.crypto import salted_hmac, constant_time_compare
from django.utils.encoding import force_text
from django.utils.text import get_text_list
from django.utils import timezone
from django.utils.translation import pgettext_lazy, ungettext, ugettext, ugettext_lazy as _
from ckeditor.widgets import CKEditorWidget
from .models import Collection
from mptt.forms     import TreeNodeChoiceField, MoveNodeForm


COMMENT_MAX_LENGTH = getattr(settings, 'COMMENT_MAX_LENGTH', 3000)
DEFAULT_COMMENTS_TIMEOUT = getattr(settings, 'COMMENTS_TIMEOUT', (2 * 60 * 60))  # 2h

class CollectForm(forms.ModelForm, forms.ChoiceField):
    def __init__(self, *args, **kwargs):
        self.target = kwargs.pop('valid_targets', None)
        self.public = kwargs.pop('is_public', None)
        super(CollectForm, self).__init__(*args, **kwargs)

        self.fields['collect_to'] = forms.ModelChoiceField(
            queryset = self.target,
            label   = 'Collect to',
            widget  = forms.Select(attrs={'class':'custom-select'}),
        )

        self.fields['description'] = forms.CharField(
            label = '',
            widget = CKEditorWidget(config_name='awesome_ckeditor')
        )

        # self.fields['is_public'] = forms.ChoiceField(
        #     choices = self.public,
        #     label   = 'is_public',
        #     widget  = forms.Select(attrs={'class':'custom-select'}), #, choices={'yes':1, 'No':0}
        # )

    class Meta:
        model = Collection
        fields = ['collect_to', 'description'] #, 'is_public'


# class CollectForm(forms.Form):
#     target = TreeNodeChoiceField(queryset=None)

#     def __init__(self, *args, **kwargs):
#         valid_targets = kwargs.pop('valid_targets', None)
#         #public = kwargs.pop('is_public', None)

#         super(CollectForm, self).__init__(*args, **kwargs)
#         print(valid_targets)
#         self.fields['target'].queryset = valid_targets
#         self.fields['target'].widget.attrs['class'] = 'custom-select'        

#         #print(collect_to, '--------',public,'--------',  '我是gennerate????')#, cats, type(cats))

#         # self.fields['collect_to'] = forms.ChoiceField(
#         #     choices= valid_targets,
#         #     label   = 'Collect to',
#         # )

#         self.fields['description'] = forms.CharField(
#             label = '',
#             widget = CKEditorWidget(config_name='awesome_ckeditor')
#         )

#         # self.fields['is_public'] = forms.ChoiceField(
#         #     choices = public,
#         #     label   = 'is_public',
#         #     widget  = forms.Select(attrs={'class':'custom-select'}, choices={'yes':1, 'No':0}),
#         # )

#     class Meta:
#         #model = 'Collect',
#         fields = ['collect_to', 'description',]

    
