from django.contrib.contenttypes.models import ContentType
from django.shortcuts   import render, get_object_or_404, redirect, reverse
from django.utils.translation       import ugettext_lazy as _
from django.contrib import messages
from django.conf    import settings
from Userx.utils    import UX, CTX, SITE
from Userx.models   import User
from press.models   import Cat
from .models    import Collection, Star
from .forms import CollectForm


class Collect:
    '''
    实现收藏的显示，创建，修改，删除，以及移动等
    '''
    
    def __init__(self, request, *args, **kwargs):
        self.request= request
        self.action = kwargs.pop('action', None)
        self.cType  = kwargs.pop('cType', None)
        self.upk    = kwargs.pop('upk', None)
        self.cpk    = kwargs.pop('cpk', None)
        self.MODEL  = ContentType.objects.get(model=self.cType) if self.cType else None  # 获取模块的ContentType 对象
        self.ux     = UX(self.request, upk=self.upk)
        self.cats   = Cat.objects.filter(user=self.ux.user)  # 获取当前用户的目录
        
        # 当前对象是否已经被收藏：
        self.collection = Collection.objects.filter(content_type=self.MODEL.pk).filter(object_pk=self.cpk).filter(user=self.ux.quser).first() if self.MODEL else None

    def collect(self):
        ctx = {
            'title': 'collect it',
            'cpk': self.cpk,
        }
        template_name = 'cs/collect_{}.html'.format(self.action) if self.action else 'cs/collections.html'
        ctx.update(CTX)
        if not self.cpk or not self.cType:
            collections = Collection.objects.filter(user=self.ux.quser)
            collections_by_cat = ((c.collect_to, c) for c in collections)

            context = {
                'title': 'Collections',
                'index': 'Collections',
                'collections': collections,
                'tetttt':'test',
            }
            context.update(ctx)

            return render(self.request, template_name, context)
        
        if not self.action:
            # 获取收藏详情
            template_name='cs/collection.html'
            context = {
                'title': 'Collection',
                'index': 'Collection',
                'collection': self.collection,
            }
            context.update(ctx)
            
            return render(self.request, template_name, context)
        
        action_dict = {'create':'收藏', 'update':'修改', 'delete':'删除'}
        if not self.ux.AUTHORITY and self.action in ['create', 'update', 'delete']:
            messages.add_message(self.request, messages.WARNING, _(('你没有{}权限...').format(action_dict[self.action])))
            return redirect(reverse('cs:collections', args=[self.ux.user.pk]))

        if self.action == 'create':
            if self.collection:
                messages.add_message(self.request, messages.WARNING, 
                    _('你已经收藏过了, 它现在在 {} 目录中。'.format(self.collection.collect_to)), fail_silently=False)
                return redirect(reverse('press:wordpress', args=[self.cpk]))
            
            favor = get_object_or_404(self.MODEL.model_class(), pk=self.cpk)
            if favor.author == self.ux.user:
                messages.add_message(self.request, messages.WARNING, _('自己不可以收藏自己的东西！'),  fail_silently=False)
                return redirect(reverse('press:wordpress', args=[self.cpk]))

            PUBLIC = (
                (1, 'YES'),
                (0, 'No'),
            )

            collection = {
                'content_object': favor,
                }

            form  = CollectForm(initial=collection, valid_targets=self.cats) #, is_public=PUBLIC
            if self.request.method == 'POST':
                form = CollectForm(self.request.POST, initial=collection, valid_targets=self.cats)
                context = {'collection': collection,}
                if form.is_valid():
                    try:
                        Collection.objects.create(
                            content_object  = favor, 
                            user    = self.ux.user, 
                            #is_public   = form.cleaned_data['is_public'],
                            collect_to  = form.cleaned_data['collect_to'], 
                            description = form.cleaned_data['description'],
                            site    = SITE
                        )

                        messages.add_message(self.request, messages.SUCCESS, _('收藏成功!'), fail_silently=True)
                        return redirect(reverse('cs:collections', args=[self.ux.user.pk]))

                    except:
                        messages.add_message(self.request, messages.ERROR, _('收藏失败了1.'))
                        return redirect(reverse('press:wordpress', args=[self.cpk]))                    

            context = {
                'form':form,
            }

            context.update(CTX)
            
            return render(self.request, template_name, context)

        if self.cpk and self.collection and self.action == 'delete':
            try:
                # Bug:
                # 在用户有多个关于同一对象的收藏时，删除会首先删除最后收藏的那个。
                # 因为前面代码中 是filter 了 first。
                Collection.objects.filter(pk=self.collection.pk).delete()
                messages.add_message(self.request, messages.SUCCESS, _('删除成功...'))
                return redirect(reverse('cs:collections', args=[self.ux.user.pk]))
                
            except:
                messages.add_message(self.request, messages.ERROR, _('删除失败了...'))
                return redirect(reverse('cs:collections', args=[self.ux.user.pk]))

        if self.cpk and self.collection and self.action == 'update':
            form  = CollectForm(valid_targets=self.cats, instance=self.collection)
           
            if self.request.method == 'POST':

                form  = CollectForm(self.request.POST, valid_targets=self.cats, instance=self.collection)
                
                if form.is_valid():
                    try:
                        form.save()
                        messages.add_message(self.request, messages.SUCCESS, _('更新成功!'), fail_silently=True)
                        return redirect(reverse('cs:collection', args=[self.ux.user.pk, self.cType, self.cpk]))

                    except:
                        messages.add_message(self.request, messages.ERROR, _('更新失败了...'))
                        return redirect(reverse('cs:collection', args=[self.ux.user.pk, self.cType, self.cpk]))

            context = {
                'form': form,
            }
            context.update(ctx)
            return render(self.request, template_name, context)
           

def collect(request, *args, **kwargs):
    '''收藏'''
    cpk = kwargs.pop('cpk', None)
    upk = kwargs.pop('upk', None)
    cType = kwargs.pop('cType', None)
    action = kwargs.pop('action', None)
    clt = Collect(request, upk=upk, cpk=cpk, cType=cType, action=action)
    return clt.collect()


class STAR:
    '''
    用户点赞/Bad操作信息，及统计信息
    '''
    def __init__(self, request, *args, **kwargs):
        self.request= request
        self.action = kwargs.pop('action', None)
        self.cType  = kwargs.pop('cType', None)
        self.upk    = kwargs.pop('upk', None)
        self.spk    = kwargs.pop('spk', None)
        self.MODEL = ContentType.objects.get(model=self.cType) if self.cType else None  # 获取App对应的 model
        self.OBJ = get_object_or_404(self.MODEL.model_class(), pk=self.spk) if self.spk else None  #  获取 APP的记录
        self.ux   = UX(self.request, upk=self.upk)

    def star(self):
        Star.objects.create(
            user = self.ux.user, content_object=self.OBJ, site=SITE,
            like = True
        ) if self.action == 'like' else Star.objects.create(
            user = self.ux.user,content_object = self.OBJ,site = SITE,
            like = False,
        )
    

    def del_star(self):
        # 消除关于它的操作记录;
        Star.objects.filter(user=self.ux.user).filter(object_pk = self.OBJ.pk).delete()


    def get_star_status(self):
        '''
        查询它是否被操作
        '''
        status=2  #赋一个默认值2 ，当作没有当前用户没有操作时的值
        stared_or_not = Star.objects.filter(content_type=self.MODEL.pk).filter(object_pk=self.spk).filter(user=self.ux.quser)
        for son in stared_or_not:
            if son:
                status = 1 if son.like else 0 # 如果查到当前用户已经操作了，那获取操作的结果，True即赞， False 即Bad
        
        return status

    def star_count(self):
        return Star.objects.filter(object_pk=self.spk).count()

    def like_count(self):
        return Star.objects.filter(object_pk=self.spk).filter(like=True).count()

    def unlike_count(self):
        return Star.objects.filter(object_pk=self.spk).filter(like=False).count()


def star(request,*args, **kwargs):
    upk = kwargs.pop('upk', None)
    spk = kwargs.pop('spk', None)
    action = kwargs.pop('action', None)
    cType  = kwargs.pop('cType', None)

    st = STAR(request, upk=upk, spk=spk, action=action, cType=cType)
    
    # 不等于2 说明已经点过来了,再点就是取消
    # 否则创建记录
    st.del_star() if st.get_star_status() !=2  else st.star()
    
    #messages.add_message(request, messages.SUCCESS, _(('{}成功').format('点赞' if action else '差评')), fail_silently=False)
    return redirect(reverse('press:wordpress', args=[spk]))