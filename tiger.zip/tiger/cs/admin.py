from django.contrib import admin
from .models import Collection, Star, Score

admin.site.register(Collection)
admin.site.register(Star)
admin.site.register(Score)
