from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.contrib.sites.models        import Site
from django.utils.translation   import ugettext_lazy as _
from django.utils.encoding      import force_text
from django.db.models           import F, signals
from django_comments.signals    import comment_was_posted
from django_comments_xtd.views  import XtdComment, TmpXtdComment

from django.urls    import reverse
from django.utils   import timezone
from django.conf    import settings
from django.db      import models
from press.models   import Cat
from Userx.utils    import SITE


COLLECTION_DES_MAX_LENGTH = getattr(settings, 'COLLECTION_DES_MAX_LENGTH', 1000)

class CSManager(models.Manager):
    def in_moderation(self):
        """·
        QuerySet for all comments currently in the moderation queue.
        """
        return self.get_queryset().filter(is_public=False, is_removed=False)

    def for_model(self, model):
        """
        QuerySet for all comments for a particular model (either an instance or
        a class).
        """
        ct = ContentType.objects.get_for_model(model)
        qs = self.get_queryset().filter(content_type=ct)
        if isinstance(model, models.Model):
            qs = qs.filter(object_pk=force_text(model._get_pk_val()))
        return qs

class BaseCSAbstractModel(models.Model):
    """
    An abstract base class for collection and star
    """
    content_type = models.ForeignKey(ContentType,
                                     verbose_name=_('content type'),
                                     related_name="content_type_set_for_%(class)s",
                                     on_delete=models.CASCADE)
    object_pk = models.TextField(_('object ID'))
    content_object = GenericForeignKey(ct_field="content_type", fk_field="object_pk")
    site = models.ForeignKey(Site, on_delete=models.CASCADE)

    class Meta:
        abstract = True

    def get_content_object_url(self):
        """
        Get a URL suitable for redirecting to the content object.
        """
        return reverse(
            "cs",
            args=(self.content_type_id, self.object_pk)
        )

class CSAbstractModel(BaseCSAbstractModel):
    """
    A user collect or star about some object.
    """
    user    = models.ForeignKey(
                settings.AUTH_USER_MODEL, 
                verbose_name=_('user'), 
                related_name="%(class)s_collection", 
                null=True,
                on_delete=models.SET_NULL, 
            )
    create_time = models.DateTimeField(_('date/time submitted'), auto_now_add=True, db_index=True)

    objects = CSManager()

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.create_time is None:
            self.create_time = timezone.now()
        super(CSAbstractModel, self).save(*args, **kwargs)

class Collection(CSAbstractModel):
    collect_to  = models.ForeignKey(Cat, _('Catalog'))
    description = models.TextField(_('Description'), max_length=COLLECTION_DES_MAX_LENGTH)
    is_public   = models.BooleanField(_('is public'), default=True, help_text=_('is public or not? '))
    is_removed  = models.BooleanField(_('is removed'), default=False, help_text=_('delete it or not?'))
    update_time = models.DateTimeField(_('update time'), auto_now=True)

    class Meta:
        verbose_name = _('collection')
        verbose_name_plural = _('collections')
        ordering = ('collect_to', 'create_time',)
        
    def __str__(self):
        # Jack 收藏了 [创业未半而中道暴富]
        # 如果不能一夜暴富，两夜也行， 一个月也行。。。。
        # 
        return '{} collects [{}] \n {}...\n'.format(self.user, self.content_object, self.description[:100])

    def get_as_text(self):
        """
        Return this collection description as plain text.
        """
        d = {
            'user': self.user or self.name,
            'date': self.submit_date,
            'description': self.description,
        }
        return _('Posted by %(user)s at %(date)s\n\n%(description)s') % d


# class StarManager(models.Manager):
#     # def get_queryset(self):
#     #     return super().get_queryset().filter(status__gt=0)


class Star(CSAbstractModel):
    like    = models.BooleanField(verbose_name=_('like or not?'), )

    def __str__(self):
        return '{} like it!'.format(self.user) if self.like else '{} dislike it!'.format(self.user)


class Score(BaseCSAbstractModel):
    """当用户点击评论，收藏 或赞时，加分到某个表中去."""
    score = models.PositiveIntegerField(verbose_name='Score')

    # TODO: Define fields here

    class Meta:
        """Meta definition for Score."""

        verbose_name = 'Score'
        verbose_name_plural = 'Scores'

    def __str__(self):
        return '{}的得分是{}'.format(self.content_object, self.score)


def star_score_update(sender, instance, signal, *args, **kwargs):
    OBJ = Score.objects.filter(object_pk = instance.object_pk)
    Score.objects.filter(object_pk=instance.object_pk).update(score = F('score') + 1) if OBJ else Score.objects.create(
            object_pk = instance.object_pk,
            content_type = instance.content_type,
            score = 1,
            site = SITE
        )

def collection_score_update(sender, instance, signal, *args, **kwargs):
    OBJ = Score.objects.filter(object_pk = instance.object_pk)

    Score.objects.filter(object_pk=instance.object_pk).update(score = F('score') + 3) if OBJ else Score.objects.create(
            object_pk = instance.object_pk,
            content_type = instance.content_type,
            score = 3,
            site = SITE
        )
   
def comment_score_update(sender, comment, signal, *args, **kwargs):
    OBJ = Score.objects.filter(object_pk = comment.object_pk)
    print('ehllllllll')
    Score.objects.filter(object_pk=comment.object_pk).update(score = F('score') + 5) if OBJ else Score.objects.create(
            object_pk = comment.object_pk,
            content_type = comment.content_type,
            score = 5,
            site = SITE
        )

signals.post_save.connect(star_score_update, sender=Star)  ##  BUG 啊！！！，取消了再赞，分数继续增加啊！操
signals.post_save.connect(collection_score_update, sender=Collection)
comment_was_posted.connect(comment_score_update, sender=TmpXtdComment)

# star + 1
# Collection + 2
# comments +5

#TODO:
## 如果用户已经收藏，取消收藏 链接
# 如果用户已经点赞，取消点赞链接？？？

