from django  import forms
from .models import Cat, Press, Star, Collection, Comment
from django.utils.translation import ugettext_lazy as _
from ckeditor.widgets import CKEditorWidget
from mptt.forms import MoveNodeForm


# class MoveForm(MoveNodeForm):
#     def __init__(self, *args, **kwargs):
#         super(MoveForm, self).__init__(*args, **kwargs)

#         self.fields['target'] = forms.ModelChoiceField(
#             queryset= self.cats,
#             label   = 'Move to ',
#             widget  = forms.Select(attrs={'class':'custom-select'}),
#             empty_label = _('Select what cat you want to move to....'), 
#         )

#     class Meta:
#         fields = ['target']

class CatForm(forms.ModelForm):
    # parent = forms.CharField(
    #     label  = _('上级目录'),
    #     #widget  = forms.widgets.Select(attrs={'class': 'custom-control'})
    # )

    class Meta:
        model = Cat
        fields = ['cat', 'bio']

class CatMoveForm(MoveNodeForm, forms.ChoiceField):
    def __init__(self, *args, **kwargs):
        valid_targets = kwargs.pop('valid_targets', None)
        super(CatMoveForm, self).__init__(*args, **kwargs)
        self.fields['target'] = forms.ChoiceField(
            choices=valid_targets,
            #choices= [[1, 'cccc'], [3, 'aaa']],
            label   = 'Move to ',
            widget  = forms.Select(attrs={'class':'custom-select'}),
            #empty_label = _('Select what cat you want to move to....'), 
        )
    
    class Meta:
        fields  = ['target']


class PressForm(forms.ModelForm, forms.ChoiceField):
    def __init__(self, *args, **kwargs):
        cats = kwargs.pop('cats', None)
        super(PressForm, self).__init__(*args, **kwargs)

        self.fields['cat'] = forms.ModelChoiceField(
            queryset = cats,
            label   = 'Catalog',
            empty_label = None,
            widget  = forms.Select(attrs={'class':'custom-select'}),
        )

    title   = forms.CharField(
        label   = 'title',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder':'title'})
    )
    subtitle   = forms.CharField(
        label   = 'subtitle',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder':'subtitle'})
    )

    content = forms.CharField(
        label = '',
        widget = CKEditorWidget(config_name='awesome_ckeditor')
    )
   
    class Meta:
        model = Press
        fields = ['cat', 'title', 'subtitle', 'status', 'content'] #'author', 


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['comment']