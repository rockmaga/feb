from django.urls import path
from .views import cats, press #, move, wordpress, write


app_name = 'press'

urlpatterns = [
    path('u<int:upk>/cats/', cats, name='cats'),
    path('u<int:upk>/cats/<int:cpk>', cats, name='cats'),
    path('u<int:upk>/cats/<int:cpk>/<action>/', cats, name='cat'),
    #path('u<int:upk>/cats/<int:cpk>/delete/confirm', cat_delete_confirm, name='cat_delete_confirm'),

    #path('u<int:upk>/write', write, name='write'),
    path('<int:spk>/wordpress', press, name='wordpress'),
    path('<int:upk>/press/<int:spk>/<action>', press, name='press'),  # update, delete
    
    #path('u<int:upk>/press/<int:spk>', press, name='press'),
    #path('u<int:upk>/press/<int:spk>/<action>/', move, name='move'),
]


# TODO:
# 1. 头像上传文件过大，报错无页面
# 413 Request Entity Too Large
# nginx/1.12.2