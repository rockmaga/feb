
from django.contrib.auth.decorators import login_required
from django.utils.translation       import ugettext_lazy as _
from django.shortcuts   import render, redirect, get_object_or_404, reverse
from mptt.exceptions    import InvalidMove
from mptt.forms     import TreeNodeChoiceField, MoveNodeForm
from django.conf    import settings
from django.contrib import messages
from Userx.utils    import UX, CTX
from Userx.models   import User, Party, Membership
from cs.models  import Collection
from .models    import Cat, Press, Comment
from .forms     import CatForm, CatMoveForm, PressForm, CommentForm
# from cs.models  import Star
from cs.views   import STAR


class CAT:
    '''
    目录：用户创建时初始化一个默认目录：Cat
    TODO: 
    有两个以上根目录时，当只显示一个根目录时，却没有返回，好像不太妙
    '''
    def __init__(self, request, *args, **kwargs):
        self.request= request
        self.action = kwargs.pop('action', None)
        self.upk    = kwargs.pop('upk', None)
        self.cpk    = kwargs.pop('cpk', None)
        self.ux     = UX(self.request, self.upk)
        
        self.ROOT_COUNT = Cat.objects.filter(user=self.ux.user).filter(level=0).count()
        self.CAT_COUNT  = Cat.objects.filter(user=self.ux.user).count()

        self.prs = Press.objects.filter(author=self.ux.quser)

        self.prs_by_cat = {} #目录为key, 次级目录或文章的为value的字典，template 中以是否存在title 字段 区别次级目录与文章

        self.cts = Cat.objects.filter(pk=self.cpk) if self.cpk else Cat.objects.filter(user=self.ux.quser).filter(level=0)
        self.collections = Collection.objects.filter(user=self.ux.quser)

        for ct in self.cts:
                self.prs_by_cat[ct] = [cc for cc in list(ct.get_children())]
                for pr in self.prs:
                    if pr.cat == ct:
                        self.prs_by_cat[ct].append(pr)  #归档文档到对应的目录中
                
                # 把收藏的东西也根据目录分别归档
                for clt in self.collections:
                    if clt.collect_to == ct:
                        self.prs_by_cat[ct].append(clt)

        if self.cts.first():   # emmm·····如果当前节点的存在？ 
            self.contains = len(self.prs_by_cat[self.cts.first()]) if self.cpk else self.cts.count() #此目录不管有没有中节点，还是有文章存在，都不允许删除
            self.allowed_create = self.cts.first().get_level() < settings.MPTT_LEVEL_MAX and self.ROOT_COUNT < settings.CATS_ROOTS_MAX and self.CAT_COUNT < settings.CATS_COUNT_MAX
            #支持最大根目录数为10，目录最深level为4, 目录总数为30, --->conf.settings    
        else:
            messages.add_message(self.request, messages.WARNING, _('你查找的目录并不存在...'), fail_silently=False) #不如直接送它到根目录吧

    def Operate(self):
        template_name = 'press/cat_{}.html'.format(self.action) if self.action else 'press/cats.html'
        
        ctx = {
            'index': '| Catalog {}'.format(self.action.capitalize() if self.action else '| Catalog'),
            'title': 'Catalog {}'.format(self.action.capitalize() if self.action else 'Catalog'),
            'press_by_cat': self.prs_by_cat,
            'cpk': self.cpk,
            'upk': self.ux.user.pk
        }

        ctx.update(CTX)

        if self.action and self.cpk:
            if not self.ux.AUTHORITY:
                messages.add_message(self.request, messages.WARNING, _('Sorry! You have no authority to {} the cat.'.format(self.action)), fail_silently=True)
                return redirect(reverse('press:cats', args=[self.ux.user.pk, self.cpk])) #???

        if self.action == 'create':  # create 时，self.cpk可为None
            if  self.allowed_create:
                form = CatForm()

                if self.request.method == 'POST':
                    form = CatForm(self.request.POST)
                    if form.is_valid():  ## 如果相同的目录要不要校验？ 傻子才作一样的目录名自己迷惑自己
                        new_cat = form.save(commit=False)
                        new_cat.user    = self.ux.user
                        new_cat.parent  = self.cts.first()
                        new_cat.save()
                        messages.add_message(self.request, messages.SUCCESS,
                            _('Create Catalog successfully!'), fail_silently=False
                        )
                        return redirect(reverse('press:cats', args=[self.ux.user.pk, new_cat.pk]))

                
                context = {'form' : form,}
                context.update(ctx)

                return render(self.request, template_name, context)

            else:
                messages.add_message(self.request, messages.WARNING, 
                    _('目录总数不能超过 {} 个， 且根目录最多 {} 个，目录级数最深 {} 级'.format(
                        settings.CATS_COUNT_MAX, settings.CATS_ROOTS_MAX, settings.MPTT_LEVEL_MAX + 1)
                        ),
                    fail_silently=False)
                return redirect(reverse('press:cats', args=[self.ux.user.pk, self.cpk ]))

        elif self.action == 'update':
            form = CatForm(instance=self.cts.first())

            if self.request.method == 'POST':
                form = CatForm(self.request.POST, instance=self.cts.first())
                if form.is_valid():  
                    form.save()
                    messages.add_message(
                        self.request, 
                        messages.SUCCESS,
                        _('Update {} successfully!'.format(self.cts.first())), fail_silently=False
                    )
                    return redirect(reverse('press:cats', args=[self.ux.user.pk, self.cpk]))
            
            context = {'form' : form,}
            context.update(ctx)

            return render(self.request, template_name, context)

        elif self.action == 'move':
            parent_pk = self.cts.first().get_parents().pk
            #当前节点不可以自家下代移动：
            EX_NODE = [ ds.pk for ds in self.cts.first().get_descendants()] 
            #不能向自己节点移动：
            EX_NODE.append(self.cpk)
            CAT_POSITION = (
                ('first-child', '...的目录内'),
                ('left', '...的前面'),
                ('right', '...的后面'),
            )
            qs = Cat.objects.filter(user=self.ux.user).exclude(pk__in=EX_NODE)
            
            form = MoveNodeForm(self.cts.first(), valid_targets=qs, position_choices=CAT_POSITION) # target_select_size=15,level_indicator='.....'

            if self.request.method == 'POST':
                form = MoveNodeForm(self.cts.first(), self.request.POST, position_choices=CAT_POSITION)
                
                if form.is_valid():
                    try:
                        form.save()
                        messages.add_message(
                            self.request, messages.SUCCESS, 
                            _('Great! "{}" has been moved to {} {}. '.format(
                                self.cts.first().cat, 
                                form.cleaned_data['target'],
                                form.cleaned_data['position'])), fail_silently=False)
                        return redirect(reverse('press:cats', args=[self.ux.user.pk, parent_pk]))
                    except InvalidMove:
                        pass
                    
            context = {
                'title': 'move '+ self.cts.first().cat + ' to ...',
                'form': form,
            }

            context.update(ctx)
            return render(self.request, template_name, context)

        elif self.action == 'move2':
            #不能向下移动：
            EX_NODE = [ ds.pk for ds in self.cts.first().get_descendants()]
            EX_NODE.append(self.cpk)
            EX_NODE.append(self.cts.first().get_parents().pk)

            qs =  Cat.objects.filter(user=self.user.account()).exclude(pk__in=EX_NODE)

            form = CatMoveForm(self.cts.first(), valid_targets=[[c, c] for c in qs])
            
            if self.request.method == 'POST':
                print(self.request.POST)
                form = CatMoveForm(self.cts.first(), self.request.POST)
                print(form)
                if form.is_valid():
                    form.save()
                    messages.add_message(self.request, messages.SUCCESS, _('Great! ""{}" has been deleted. '.format(self.cts.first().cat)), fail_silently=False)
                    return redirect(reverse('press:cats', args=[self.upk, self.cpk]))

            context = {
                'form':form,
            }

            context.update(ctx)
            return render(self.request, template_name, context)

        elif self.action == 'delete':
            if self.contains:
                messages.add_message(self.request, messages.WARNING, _('The Catalog is not null , can\'t be deleted!'), fail_silently=False)
                return redirect(reverse('press:cats', args=[self.ux.user.pk, self.cts.first().pk])) #??? 可能在次级目录，是否一定要返回总目录？
            else:
                cat_deleted = self.cts.first()
                parent = cat_deleted.get_parents().pk
                
                self.cts.first().delete()
                messages.add_message(self.request, messages.INFO, _('Great! ""{}" has been deleted. '.format(cat_deleted.cat)), fail_silently=False)
                return redirect(reverse('press:cats', args=[self.ux.user.pk, parent]))
                #return redirect(reverse('press:cat_delete_confirm', args=[self.upk, self.cpk])) # 先让用户口确认一下
        
        else:
            return render(self.request, template_name, ctx)

class PRS:
    def __init__(self, request, *args, **kwargs):
        self.request= request
        self.action = kwargs.pop('action', None)
        self.upk    = kwargs.pop('upk', None)
        self.spk    = kwargs.pop('spk', None)
        self.cpk    = kwargs.pop('cpk', None)       # move the press to other catalog
        self.ux     = UX(self.request, self.upk)
        self.user   = get_object_or_404(User, username=self.request.user)
        self.cats_qs= Cat.objects.filter(user=self.ux.user)
        self.star   = STAR(self.request, spk=self.spk, upk=self.ux.user.pk, cType='press') if self.spk else None
        self.prs    = get_object_or_404(Press, pk=self.spk) if self.spk else Press.objects.filter(author=self.ux.quser)


    def press(self):
        self.ctx = {
            'index': '| Press {}'.format(self.action.capitalize()) if self.action else '| Press',
            'title': 'Press {}'.format(self.action.capitalize()) if self.action else 'Press',
            #'press': self.prs,
        }
        self.ctx.update(CTX)
        
        if self.spk:
            if  self.action == 'update':
                template_name = 'press/write.html'
                form = PressForm(cats=self.cats_qs, instance=self.prs) #

                if self.request.method == 'POST':
                    form = PressForm(self.request.POST, instance=self.prs, cats=self.cats_qs)
                    if form.is_valid():
                        form.save()
                        messages.add_message(self.request, messages.SUCCESS, 
                            _('Great! updete  [ {} ]  successfully.'.format(self.prs.title)), fail_silently=False)
                        return redirect(reverse('press:wordpress', args=[self.spk]))

                context = {
                    'form':form,
                }
                context.update(self.ctx)

                return render(self.request, template_name, context)

            elif self.action == 'delete':
                Press.objects.filter(pk=self.spk).update(status=0)
                messages.add_message(self.request, messages.INFO, _('Great! ""{}" has been deleted. '.format(self.prs.title)), fail_silently=False)
                return redirect(reverse('press:cats', args=[self.ux.user.pk, self.prs.cat.pk]))

            elif self.action == 'move':
                pass
                # 移动，放在修改里了吧
            else:
                # 没有action 则显示 wordpress
                #print(self.star.like_count(), self.star.get_star_status(), self.prs.author, self.star.unlike_count())
                template_name = 'press/wordpress.html'

                context = {
                    'press':self.prs,
                    'object':self.prs,
                    'star_status': self.star.get_star_status(),
                    'like_num': self.star.like_count(),
                    'unlike_num':self.star.unlike_count(),
                }
                context.update(CTX)

                return render(self.request, template_name, context)

        else:
            if self.action == 'write':
                form = PressForm(cats=self.cats_qs) #, author=author
                
                template_name = 'press/write.html'

                if not self.ux.AUTHORITY:
                    messages.add_message(self.request, messages.WARNING, _('Sorry! You must login first.'), fail_silently=True)
                    return redirect(reverse('press:cats', args=[self.ux.user.pk, None]))

                if self.request.method == 'POST':
                    form = PressForm(self.request.POST, self.request.FILES, cats=self.cats_qs)
                    if form.is_valid():
                        new_press = form.save(commit=False)
                        new_press.author = self.ux.user
                        new_press.save()
                        messages.add_message(self.request, messages.SUCCESS,
                            _('[ {} ]Create press successfully!'.format(new_press.get_status_display())), fail_silently=False)
                        return redirect(reverse('press:wordpress', args=[new_press.pk]))

                context = {
                    'form':form,
                }
                context.update(self.ctx)

                return render(self.request, template_name, context)
            else:
                messages.add_message(self.request, messages.WARNING, _('please, go back!'), fail_silently=False)
                return redirect('/')

def cats(request, *args, **kwargs):
    upk = kwargs.pop('upk', None)
    cpk = kwargs.pop('cpk', None)
    cat = CAT(request, upk=upk, cpk=cpk, *args, **kwargs)
    return cat.Operate()

def press(request, *args, **kwargs):
    upk = kwargs.pop('upk', None)
    spk = kwargs.pop('spk', None)
    action = kwargs.pop('action', None)

    #print(upk, spk, action)
    prs = PRS(request, upk=upk, spk=spk, action=action)
    return prs.press()


    # def operate(self):
    #     template_name = 'press/press_{}.html'.format(self.action) if self.spk else 'press/press.html'

    #     ctx = {
    #         'index': '| Press {}'.format(self.action.capitalize() if self.action else '| Press'),
    #         'title': 'Press {}'.format(self.action.capitalize() if self.action else 'Press'),
    #         'user': self.user.account(),
    #         'spk': self.spk,
    #         'upk': self.upk
    #     }
    #     ctx.update(CTX)

    #     if self.action and self.spk:
    #         if not self.user.AUTHORITY:
    #             messages.add_message(self.request, messages.WARNING, _('Sorry! You have no authority to {} the press.'.format(self.action.capitalize())), fail_silently=True)
    #             return redirect(reverse('press:press', args=[self.spk]))
                
    #     if self.action == 'write':
    #         form = PressForm(cats=self.cats_qs)
    #         template_name = 'press/write.html'

    #         if not self.user.AUTHORITY:
    #             messages.add_message(self.request, messages.WARNING, _('Sorry! You must login first.'), fail_silently=True)
    #             return redirect(reverse('press:cats', args=[self.upk, None]))

    #         if self.request.method == 'POST':
    #             form = PressForm(self.request.POST, cats=self.cats_qs)
    #             if form.is_valid():
    #                 new_press = form.save(commit=False)
    #                 new_press.author = self.user.account()
    #                 new_press.save()
    #                 messages.add_message(self.request, messages.SUCCESS,
    #                      _('[ {} ]Create press successfully!'.format(new_press.get_status_display())), fail_silently=False)
    #                 return redirect(reverse('press:wordpress', args=[new_press.pk]))
            
    #         context = {
    #             'form':form,
    #         }
    #         context.update(ctx)

    #         return render(self.request, template_name, context)

    #     elif self.spk and self.action == 'update':
    #         template_name = 'press/write.html'
    #         form = PressForm(cats=self.cats_qs, instance=self.prs)

    #         if self.request.method == 'POST':
    #             form = PressForm(self.request.POST, cats=self.cats_qs, instance=self.prs)
    #             if form.is_valid():
    #                 form.save()
    #                 messages.add_message(self.request, messages.SUCCESS, 
    #                     _('Great! updete  [ {} ]  successfully.'.format(self.prs.title)), fail_silently=False)
    #                 return redirect(reverse('press:wordpress', args=[self.spk]))

    #         context = {
    #         'form':form,
    #         }
    #         context.update(CTX)

    #         return render(self.request, template_name, context)

    #     elif self.spk and self.action == 'delete':
    #         Press.objects.filter(pk=self.spk).update(status=0)
    #         messages.add_message(self.request, messages.INFO, _('Great! ""{}" has been deleted. '.format(self.prs.title)), fail_silently=False)
    #         return redirect(reverse('press:cats', args=[self.upk, self.prs.cat.pk]))

    #     elif self.spk and self.action == 'move':
    #         pass

    #     elif self.spk:
    #         context = {'press': self.prs }

    #         context.update(ctx)
    #         return render(self.request, template_name, context)

    #     else:
    #         return render(self.request, template_name, ctx)


