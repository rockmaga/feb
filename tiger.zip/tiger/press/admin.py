from django import forms
from django.contrib import admin
from ckeditor.widgets import CKEditorWidget
from .models import Cat, Press, Collection, Star, Comment


class PressAdminForm(forms.ModelForm):
    content = forms.CharField(widget=CKEditorWidget())
    class Meta:
        model = Press
        fields = '__all__'

class PressAdmin(admin.ModelAdmin):
    form = PressAdminForm

admin.site.register(Press, PressAdmin)
admin.site.register(Cat)
admin.site.register(Collection)
admin.site.register(Star)
admin.site.register(Comment)


