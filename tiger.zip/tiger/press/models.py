from django_comments_xtd.moderation     import moderator
from django_comments.moderation         import CommentModerator #, SpamModerator
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.utils.translation import ugettext_lazy as _
from django.db.models.signals import post_save, post_delete
from ckeditor.fields    import RichTextField
from mptt.models    import MPTTModel, TreeForeignKey
from django.conf    import settings
from django.urls    import reverse
from collections    import OrderedDict
from Userx.models   import User
from django.db      import models



class CatManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter().order_by('user')

class Cat(MPTTModel):
    user= models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=None)
    cat = models.CharField(_('Catalog'), max_length=22)
    bio = RichTextField(max_length=200, null=True, blank=True)
    status  = models.BooleanField(default=True)
    parent  = TreeForeignKey('self', null=True, blank=True, related_name='children', db_index=True, on_delete=None)
    

    objects = CatManager()

    class Meta:
        ordering = ['user']

    def get_absolute_url(self):
        return reverse('press:cats', args=[str(self.pk)])

    @property
    def parents(self):
        family = OrderedDict()
        rank = 0
        family[rank] = self.cat

        while self.parent:
            self = self.parent
            rank += 1
            family[rank] = self.cat

        family = sorted(family.items(), key=lambda t: t[0], reverse=True)
        return family

    def get_parents(self):
        fml = [ pt for pt in self.get_ancestors() ]
        parents = fml[-1] if len(fml)>1 else self.get_root()
        
        return parents


    def __str__(self):
        ps = ''
        for ct in self.parents:
            ps += ' / ' + ct[1]

        return '%s' % ps

class PressManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(status__gt=0)

#membership__date_joined__gt=date(1961,1,1)return redirect(reverse('press:cats', args=[self.upk, None]))
class Press(models.Model):
    STATUS = (
        (0, 'delete'),
        (1, 'draft'),
        (2, 'private'),
        (3, 'publish'),
    )

    cat = models.ForeignKey(Cat, on_delete=None, verbose_name=_('Catalog'))
    title   = models.CharField(_('Title'),max_length=60, null=False, blank=False)
    subtitle= models.CharField(_('Subtitle'),max_length=100,null=True, blank=True)
    #content = models.TextField(_('Content'), max_length=5555)
    content = RichTextField(config_name='awesome_ckeditor')
    author  = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=None, verbose_name=_('Author'))
    status  = models.PositiveSmallIntegerField(_("status"), choices=STATUS, default=3)
    collections = models.IntegerField(_('collect'), default=0)
    create_time = models.DateTimeField(_('create time'),auto_now_add=True)
    update_time = models.DateTimeField(_('update time'),auto_now=True)
    allow_comments  = models.BooleanField(_('allow comments ?'), default=True)
    collected   = GenericRelation('Collection')
    star   = GenericRelation('Star')

    objects = PressManager()

    class Meta:
        verbose_name = _('press')
        verbose_name_plural = _('presses')
        ordering = ('cat', 'create_time',)
    
    def __str__(self):
        return '{}'.format(self.title)
        
    def get_absolute_url(self):
        return reverse('press:wordpress', args=[str(self.pk)])

class Star(models.Model):
    press   = models.ForeignKey(Press, _('Press'))
    user    = models.ForeignKey(settings.AUTH_USER_MODEL, _('user'))
    star    = models.BooleanField(_('star?'))
    star_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        if self.star:
            st = 'like'
        else:
            st = 'unlike'
        return '{} {}\'s   << {} >>'.format(self.user, st, self.press.title)


class Collection(models.Model):
    press   = models.ForeignKey(Press, _('Press'))
    user    = models.ForeignKey(User, _('Collector'))
    collect_time = models.DateTimeField(verbose_name=_('Collected time'))


class Comment(MPTTModel):
    user    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=None)
    comment = RichTextField(_('Comment'), max_length=500)
    parent  = TreeForeignKey('self', null=True, blank=True, related_name='children', db_index=True, on_delete=None)
    create_time = models.DateTimeField(_('create time'),auto_now_add=True)
    update_time = models.DateTimeField(_('update time'),auto_now=True)

    def __str__(self):
        return 'comments for {}'.format(self.parent)


def Cat_init(sender, instance, signal, *args, **kwargs):
    if not Cat.objects.filter(user=instance):
        Cat.objects.create(
            user=instance,
            cat = 'Cat',
            bio = '{} \'s first Cat....'.format(instance),
        )

def Cat_delete(sender, instance, signal, *args, **kwargs):
    Cat.objects.delete(user=instance,)

# def Press_init(sender, instance, signal, *args, **kwargs):
#     if not Press.objects.filter(author=instance):
#         Press.objects.create(
#             author=instance,
#             cat     = '',  #为新用户初始化一个文章，感谢以及使用说明，这个不太好搞
#             title   = '',
#             content = '还是算了吧！'
#         )
post_save.connect(Cat_init, sender=User)

#实际上，不允许用户自己删除：
post_delete.connect(Cat_delete, sender=User)


#register our Moderator class with the django-comments-xtd’s moderator object.
#https://django-comments-xtd.readthedocs.io/en/latest/tutorial.html
class PressCommentModerator(CommentModerator):
    email_notification = True
    auto_moderate_field = 'create_time'
    moderate_after = 365

#  Visit any of the blog posts with a publish datetime older than a year and try to send a comment.
#  After confirming the comment you will see the django_comments_xtd/moderated.html template, and 
# your comment will be put on hold for approval.
moderator.register(Press, PressCommentModerator)

# test
# class PostCommentModerator(SpamModerator):
#     email_notification = True
    
#     def moderate(self, comment, content_object, request):
#         # Make a dictionary where the keys are the words of the message and
#         # the values are their relative position in the message.
#         badwords = []

#         def clean(word):
#             ret = word
#             if word.startswith('.') or word.startswith(','):
#                 ret = word[1:]
#             if word.endswith('.') or word.endswith(','):
#                 ret = word[:-1]
#             return ret

#         lowcase_comment = comment.comment.lower()
#         msg = dict([(clean(w), i)
#                     for i, w in enumerate(lowcase_comment.split())])
#         for badword in badwords:
#             if isinstance(badword, str):
#                 if lowcase_comment.find(badword) > -1:
#                     return True
#             else:
#                 lastindex = -1
#                 for subword in badword:
#                     if subword in msg:
#                         if lastindex > -1:
#                             if msg[subword] == (lastindex + 1):
#                                 lastindex = msg[subword]
#                         else:
#                             lastindex = msg[subword]
#                     else:
#                         break
#                 if msg.get(badword[-1]) and msg[badword[-1]] == lastindex:
#                     return True
#         return super(PostCommentModerator, self).moderate(comment,
#                                                           content_object,
#                                                           request)

# moderator.register(Press, PostCommentModerator)